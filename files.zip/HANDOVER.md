# SURPLUS Inc. Website — Claude Code 引き継ぎメモ

## 概要

株式会社SURPLUSの公式サイトをsurplus-jp.comにデプロイする。
静的HTMLで構成済み。GitHubにpushしてVercelでデプロイするだけの状態。

---

## 完成済みファイル構成

```
surplus-jp-com/
  index.html          ← メインサイト（完成済み）
  koukoku/
    index.html        ← 電子公告ページ（完成済み）
```

このチャットからHTMLファイル2つをダウンロード済み。

---

## やること

### 1. GitHubリポジトリ作成 & push

```bash
mkdir surplus-jp-com && cd surplus-jp-com
mkdir koukoku

# ダウンロードしたファイルをここに配置
# index.html → surplus-jp-com/index.html
# koukoku/index.html → surplus-jp-com/koukoku/index.html

git init
git add .
git commit -m "init: SURPLUS Inc. website"

git remote add origin https://github.com/【ユーザー名】/surplus-jp-com.git
git push -u origin main
```

### 2. Vercelにデプロイ

```bash
npx vercel --prod
```

または Vercel Dashboard から GitHub リポジトリをインポート → Deploy

### 3. カスタムドメイン設定

Vercel Dashboard → Project → Settings → Domains で `surplus-jp.com` を追加。
DNSはCloudflareで管理中（surplus-jp.comのメールはCloudflare Email Routing + Gmail Send As設定済み）。

Vercelが指示するDNSレコードをCloudflareに追加する。

---

## 重要情報

### 会社情報
- 会社名：株式会社SURPLUS（SURPLUS Inc.）
- 所在地：〒870-0108 大分県大分市三佐3丁目1番3号 鶴崎司法会館101号室
- 設立：令和8年4月
- 代表：田中 祐一朗
- 資本金：500万円

### 電子公告について
- 公告URL：`https://surplus-jp.com/koukoku/`
- 発起人決議書に記載済み（認証日：令和8年4月2日）
- このURLが法的に有効な電子公告媒体として機能する必要があるため、**絶対に削除・移動しない**

### デザイン方針
- モダン・クリーン、白基調
- アクセントカラー：ダークグリーン（#1e4d30）
- フォント：DM Serif Display（見出し）+ Noto Sans JP（本文）+ DM Mono（ラベル）
- 絵文字は使用しない（SVGアイコンに統一済み）

### サイト構成セクション
1. Hero（キャッチコピー＋統計カード）
2. Business（EC事業・OEM・就労支援）
3. Brands（STANRISE® / TSUKAERU LABO® / mic.an®）
4. Global（Shopee 5ヶ国展開）
5. About（会社概要テーブル＋理念）
6. Contact（メール＋フォーム）

---

## 今後の課題（任意）

- お問い合わせフォームのバックエンド実装（現在はalertのみ）
- 画像素材の追加（現在はテキスト・SVGのみ）
- surplus-jp.comのGENSPARKサイトからの完全移行確認
